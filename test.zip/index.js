// Import libraries
import { makeWASocket, useMultiFileAuthState, DisconnectReason } from '@whiskeysockets/baileys';
import TelegramBot from 'node-telegram-bot-api';
import qrcode from 'qrcode-terminal';
import fs from 'fs';

// Konfigurasi bot Telegram
const TELEGRAM_TOKEN = '6428849655:AAHhiTpc1YA6S6TKyKM6TVD-jLh6W76YdMI';
const bot = new TelegramBot(TELEGRAM_TOKEN, { polling: true });

// Log untuk menunjukkan bahwa bot Telegram telah aktif
console.log('Bot Telegram aktif!');

// Fungsi untuk membaca dan menulis ke database.json
const readDatabase = () => {
  try {
    const data = fs.readFileSync('database.json', 'utf8');
    return JSON.parse(data);
  } catch (error) {
    console.error('Gagal membaca database:', error);
    return {};
  }
};

const writeDatabase = (data) => {
  try {
    fs.writeFileSync('database.json', JSON.stringify(data, null, 2));
  } catch (error) {
    console.error('Gagal menulis ke database:', error);
  }
};

// Fungsi untuk membuat koneksi WhatsApp
const connectToWhatsApp = async () => {
  const { state, saveCreds } = await useMultiFileAuthState('auth_info');
  const sock = makeWASocket({
    auth: state,
    printQRInTerminal: true
  });

  sock.ev.on('connection.update', (update) => {
    const { qr, connection, lastDisconnect } = update;
    if (qr) {
      qrcode.generate(qr, { small: true });
    }
    if (connection === 'close') {
      const shouldReconnect = lastDisconnect.error?.output?.statusCode !== DisconnectReason.loggedOut;
      if (shouldReconnect) {
        connectToWhatsApp();
      }
    } else if (connection === 'open') {
      console.log('Koneksi ke WhatsApp berhasil!');
    }
  });

  sock.ev.on('creds.update', saveCreds);

  sock.ev.on('messages.upsert', async (m) => {
    if (m.messages && m.messages[0].message) {
      const waMessage = m.messages[0].message.conversation;
      const from = m.messages[0].key.remoteJid;

      console.log('Pesan diterima dari WhatsApp:', waMessage);

      // Simpan pengirim terakhir ke database
      const db = readDatabase();
      db.lastWhatsAppSender = from;
      writeDatabase(db);

      if (waMessage.startsWith('/menu')) {
        const menuMessage = `
*Menu Bot WhatsApp:*
1. /chattele <id_telegram> <pesan> - Kirim pesan ke Telegram.
2. /balastele <pesan> - Balas pesan ke Telegram dari WhatsApp.
3. /menu - Tampilkan menu ini.
        `;
        await sock.sendMessage(from, { text: menuMessage });
      } else if (waMessage.startsWith('/balastele')) {
        const responseMessage = waMessage.replace('/balastele ', '');
        const db = readDatabase();
        const telegramId = db[from]?.telegramId;

        if (responseMessage.trim() === '') {
          await sock.sendMessage(from, { text: 'Pesan kosong, silahkan isi terlebih dahulu.' });
        } else if (telegramId) {
          bot.sendMessage(telegramId, `Balasan dari WhatsApp: ${responseMessage}`);
          await sock.sendMessage(from, { text: 'Pesan terkirim ke Telegram, silahkan tunggu pesan selanjutnya.' });
        } else {
          console.log('Tidak ada ID Telegram yang terhubung untuk nomor ini.');
        }
      } else if (waMessage.startsWith('/chattele')) {
        const [ , telegramId, ...messageParts ] = waMessage.split(' ');
        const message = messageParts.join(' ');

        if (!telegramId || message.trim() === '') {
          await sock.sendMessage(from, { text: 'Format salah. Gunakan: /chattele <id_telegram> <pesan>' });
        } else {
          bot.sendMessage(telegramId, `Pesan dari WhatsApp: ${message}`);
          const db = readDatabase();
          db[from] = db[from] || {};
          db[from].telegramId = telegramId;
          writeDatabase(db);
          await sock.sendMessage(from, { text: 'Pesan terkirim ke Telegram.' });
        }
      }
    }
  });

  return sock;
};

let waSock;
connectToWhatsApp().then(sock => waSock = sock);

bot.onText(/\/menu/, (msg) => {
  const chatId = msg.chat.id;
  const menuMessage = `
*Menu Bot Telegram:*
1. /chatwa <nomor> <pesan> - Kirim pesan ke WhatsApp.
2. /balaswa <pesan> - Balas pesan ke WhatsApp dari Telegram.
3. /menu - Tampilkan menu ini.
  `;
  bot.sendMessage(chatId, menuMessage, { parse_mode: 'Markdown' });
});

bot.onText(/\/chatwa ?(\d*) ?(.+)?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const phoneNumber = match[1];
  const message = match[2];

  if (!phoneNumber || !message) {
    bot.sendMessage(chatId, 'Masukkan nomor telepon dan isi pesan dengan format: /chatwa <nomor> <pesan>');
    return;
  }

  const waNumber = `${phoneNumber}@s.whatsapp.net`;
  const db = readDatabase();
  db[waNumber] = db[waNumber] || {};
  db[waNumber].telegramId = chatId;
  writeDatabase(db);

  if (waSock) {
    await waSock.sendMessage(waNumber, { text: message });
    bot.sendMessage(chatId, `Pesan terkirim ke WhatsApp: ${message}`);
  } else {
    bot.sendMessage(chatId, 'Gagal terhubung ke WhatsApp.');
  }
});

bot.onText(/\/balaswa (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const responseMessage = match[1];
  const db = readDatabase();

  if (!responseMessage || responseMessage.trim() === '') {
    bot.sendMessage(chatId, 'Pesan kosong, silahkan isi terlebih dahulu.');
    return;
  }

  const lastWhatsAppSender = db.lastWhatsAppSender;

  if (lastWhatsAppSender) {
    await waSock.sendMessage(lastWhatsAppSender, { text: responseMessage });
    bot.sendMessage(chatId, `Pesan terkirim ke WhatsApp: ${responseMessage}`);
  } else {
    bot.sendMessage(chatId, 'Tidak ada pengirim WhatsApp yang diketahui untuk membalas.');
  }
});